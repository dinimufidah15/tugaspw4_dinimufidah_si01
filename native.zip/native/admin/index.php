<?php
  include_once 'top.php';
  include_once 'menu.php';
?>
<div>
<div class="container-fluid px-4">
     <h1>selamat datang di halaman</h1>
</div>  
</div>
<?php
  include_once 'bottom.php';
?>     